# LLM Wiki Workshop Agent Guide

A persistent wiki compounds knowledge instead of rediscovering it from raw fragments on every question. The student chooses the topic, supplies sources, directs exploration, approves the structure, and may manually edit every page. The agent performs extraction, synthesis, cross-linking, indexing, and bookkeeping while integrating around the student's work rather than blindly regenerating it.

Use the student's language for dialogue, questions, and explanations. The student chooses the wiki's language during setup; do not assume Russian or any other language. Do not impose a fixed academic taxonomy or any other preset folder scheme.

## Local Architecture

- `raw/` contains immutable original sources. Read from it, but never edit, move, or overwrite its contents.
- `wiki/` is the Obsidian vault and contains the synthesized Markdown knowledge base.
- `.agents/` contains the two required skills: `raw-to-structured` and `wiki-media-pipeline`.
- `wiki/index.md` is the content catalog; read it to navigate and keep it current.
- `wiki/log.md` is the append-only chronological record of changes and operations.

Obsidian provides local navigation and graph view without mandatory synchronization or a server. The student may use Obsidian or another Markdown reader. No frontend, client-server, deployment, or hosted runtime is required.

## Confirmed Wiki Structure

<!-- WIKI_STRUCTURE:UNCONFIRMED -->

After explicit student approval, replace the marker above with `<!-- WIKI_STRUCTURE:CONFIRMED -->` and record the approved decisions in this block:

- Topic:
- Folders and sections:
- Page types:
- Naming conventions:
- Wiki language:
- Link conventions:

The confirmed structure is the schema for subsequent work. Evolve it only with the student, and never replace it with a predetermined domain taxonomy.

## SETUP

At the start of a session, inspect the structure marker. If `<!-- WIKI_STRUCTURE:CONFIRMED -->` is present, skip all SETUP steps and go directly to MAINTENANCE. Otherwise, complete these steps in order:

1. Explain the LLM wiki concept and its practical value for the student.
2. Ask for the wiki topic, desired folders/sections/page categories, language, and special link preferences.
3. Inspect `raw/`. If no ingestible example exists, ask for one and wait.
4. Run `source_file_chunks.py inspect` before full reading. If needed, split using the `raw-to-structured` skill, append the split to `wiki/log.md`, tell the student the chunk count and manifest path, and ask permission to compact context. Continue only after approval.
5. Peek at a safe amount of source material or one chunk; identify the actual entity, concept, and source categories present.
6. Propose a structure based on those materials and the student's preferences. By default, use document-relative Markdown page links with `.md` filenames and document-relative media links during structure proposal and subsequent work; any student-requested variation must be explicit in the confirmed structure.
7. Only after explicit approval, replace the marker with `<!-- WIKI_STRUCTURE:CONFIRMED -->` and record the topic, folders, page types, naming, language, and link conventions in the structure block.

Presenting a proposal is not approval. Do not create a confirmed schema until the student explicitly approves it.

## MAINTENANCE

- Invoke `raw-to-structured` for ingestion and `wiki-media-pipeline` whenever visual content is processed. Follow their current extraction, chunking, media, and local-link guidance.
- Read existing pages before changing them. Manual student edits take precedence over blind regeneration; preserve those edits and integrate new material around them.
- Keep sources immutable and claims attributed. Flag contradictions with their respective sources rather than silently choosing a winner.
- Update source pages, relevant content pages, backlinks, and `wiki/index.md` according to the confirmed structure.
- Append every wiki content change to `wiki/log.md`. Also append every source split, even when no content page has changed. Never rewrite or delete earlier log entries.
- The log entry itself does not trigger another log entry.
- After context compaction, recover split progress from `wiki/log.md` and the split's `manifest.json` before processing more material. Process one chunk at a time and do not load all chunks back into one context.

---

The following is the original conceptual reference. The preceding workshop rules take precedence over it, particularly regarding manual student editing and preservation of those edits.

# LLM Wiki

A pattern for building personal knowledge bases using LLMs.

This is an idea file, it is designed to be copy pasted to your own LLM Agent (e.g. OpenAI Codex, Claude Code, OpenCode / Pi, or etc.). Its goal is to communicate the high level idea, but your agent will build out the specifics in collaboration with you.

## The core idea

Most people's experience with LLMs and documents looks like RAG: you upload a collection of files, the LLM retrieves relevant chunks at query time, and generates an answer. This works, but the LLM is rediscovering knowledge from scratch on every question. There's no accumulation. Ask a subtle question that requires synthesizing five documents, and the LLM has to find and piece together the relevant fragments every time. Nothing is built up. NotebookLM, ChatGPT file uploads, and most RAG systems work this way.

The idea here is different. Instead of just retrieving from raw documents at query time, the LLM **incrementally builds and maintains a persistent wiki** — a structured, interlinked collection of markdown files that sits between you and the raw sources. When you add a new source, the LLM doesn't just index it for later retrieval. It reads it, extracts the key information, and integrates it into the existing wiki — updating entity pages, revising topic summaries, noting where new data contradicts old claims, strengthening or challenging the evolving synthesis. The knowledge is compiled once and then *kept current*, not re-derived on every query.

This is the key difference: **the wiki is a persistent, compounding artifact.** The cross-references are already there. The contradictions have already been flagged. The synthesis already reflects everything you've read. The wiki keeps getting richer with every source you add and every question you ask.

You never (or rarely) write the wiki yourself — the LLM writes and maintains all of it. You're in charge of sourcing, exploration, and asking the right questions. The LLM does all the grunt work — the summarizing, cross-referencing, filing, and bookkeeping that makes a knowledge base actually useful over time. In practice, I have the LLM agent open on one side and Obsidian open on the other. The LLM makes edits based on our conversation, and I browse the results in real time — following links, checking the graph view, reading the updated pages. Obsidian is the IDE; the LLM is the programmer; the wiki is the codebase.

This can apply to a lot of different contexts. A few examples:

- **Personal**: tracking your own goals, health, psychology, self-improvement — filing journal entries, articles, podcast notes, and building up a structured picture of yourself over time.
- **Research**: going deep on a topic over weeks or months — reading papers, articles, reports, and incrementally building a comprehensive wiki with an evolving thesis.
- **Reading a book**: filing each chapter as you go, building out pages for characters, themes, plot threads, and how they connect. By the end you have a rich companion wiki. Think of fan wikis like [Tolkien Gateway](https://tolkiengateway.net/wiki/Main_Page) — thousands of interlinked pages covering characters, places, events, languages, built by a community of volunteers over years. You could build something like that personally as you read, with the LLM doing all the cross-referencing and maintenance.
- **Business/team**: an internal wiki maintained by LLMs, fed by Slack threads, meeting transcripts, project documents, customer calls. Possibly with humans in the loop reviewing updates. The wiki stays current because the LLM does the maintenance that no one on the team wants to do.
- **Competitive analysis, due diligence, trip planning, course notes, hobby deep-dives** — anything where you're accumulating knowledge over time and want it organized rather than scattered.

## Architecture

There are three layers:

**Raw sources** — your curated collection of source documents. Articles, papers, images, data files. These are immutable — the LLM reads from them but never modifies them. This is your source of truth.

**The wiki** — a directory of LLM-generated markdown files. Summaries, entity pages, concept pages, comparisons, an overview, a synthesis. The LLM owns this layer entirely. It creates pages, updates them when new sources arrive, maintains cross-references, and keeps everything consistent. You read it; the LLM writes it.

**The schema** — a document (e.g. CLAUDE.md for Claude Code or AGENTS.md for Codex) that tells the LLM how the wiki is structured, what the conventions are, and what workflows to follow when ingesting sources, answering questions, or maintaining the wiki. This is the key configuration file — it's what makes the LLM a disciplined wiki maintainer rather than a generic chatbot. You and the LLM co-evolve this over time as you figure out what works for your domain.

## Operations

**Ingest.** You drop a new source into the raw collection and tell the LLM to process it. An example flow: the LLM reads the source, discusses key takeaways with you, writes a summary page in the wiki, updates the index, updates relevant entity and concept pages across the wiki, and appends an entry to the log. A single source might touch 10-15 wiki pages. Personally I prefer to ingest sources one at a time and stay involved — I read the summaries, check the updates, and guide the LLM on what to emphasize. But you could also batch-ingest many sources at once with less supervision. It's up to you to develop the workflow that fits your style and document it in the schema for future sessions.

**Query.** You ask questions against the wiki. The LLM searches for relevant pages, reads them, and synthesizes an answer with citations. Answers can take different forms depending on the question — a markdown page, a comparison table, a slide deck (Marp), a chart (matplotlib), a canvas. The important insight: **good answers can be filed back into the wiki as new pages.** A comparison you asked for, an analysis, a connection you discovered — these are valuable and shouldn't disappear into chat history. This way your explorations compound in the knowledge base just like ingested sources do.

**Lint.** Periodically, ask the LLM to health-check the wiki. Look for: contradictions between pages, stale claims that newer sources have superseded, orphan pages with no inbound links, important concepts mentioned but lacking their own page, missing cross-references, data gaps that could be filled with a web search. The LLM is good at suggesting new questions to investigate and new sources to look for. This keeps the wiki healthy as it grows.

## Indexing and logging

Two special files help the LLM (and you) navigate the wiki as it grows. They serve different purposes:

**index.md** is content-oriented. It's a catalog of everything in the wiki — each page listed with a link, a one-line summary, and optionally metadata like date or source count. Organized by category (entities, concepts, sources, etc.). The LLM updates it on every ingest. When answering a query, the LLM reads the index first to find relevant pages, then drills into them. This works surprisingly well at moderate scale (~100 sources, ~hundreds of pages) and avoids the need for embedding-based RAG infrastructure.

**log.md** is chronological. It's an append-only record of what happened and when — ingests, queries, lint passes. A useful tip: if each entry starts with a consistent prefix (e.g. `## [2026-04-02] ingest | Article Title`), the log becomes parseable with simple unix tools — `grep "^## \[" log.md | tail -5` gives you the last 5 entries. The log gives you a timeline of the wiki's evolution and helps the LLM understand what's been done recently.

## Optional: CLI tools

At some point you may want to build small tools that help the LLM operate on the wiki more efficiently. A search engine over the wiki pages is the most obvious one — at small scale the index file is enough, but as the wiki grows you want proper search. [qmd](https://github.com/tobi/qmd) is a good option: it's a local search engine for markdown files with hybrid BM25/vector search and LLM re-ranking, all on-device. It has both a CLI (so the LLM can shell out to it) and an MCP server (so the LLM can use it as a native tool). You could also build something simpler yourself — the LLM can help you vibe-code a naive search script as the need arises.

## Tips and tricks

- **Obsidian Web Clipper** is a browser extension that converts web articles to markdown. Very useful for quickly getting sources into your raw collection.

## Why this works

The tedious part of maintaining a knowledge base is not the reading or the thinking — it's the bookkeeping. Updating cross-references, keeping summaries current, noting when new data contradicts old claims, maintaining consistency across dozens of pages. Humans abandon wikis because the maintenance burden grows faster than the value. LLMs don't get bored, don't forget to update a cross-reference, and can touch 15 files in one pass. The wiki stays maintained because the cost of maintenance is near zero.

The human's job is to curate sources, direct the analysis, ask good questions, and think about what it all means. The LLM's job is everything else.

The idea is related in spirit to Vannevar Bush's Memex (1945) — a personal, curated knowledge store with associative trails between documents. Bush's vision was closer to this than to what the web became: private, actively curated, with the connections between documents as valuable as the documents themselves. The part he couldn't solve was who does the maintenance. The LLM handles that.


## Note

This document is intentionally abstract. It describes the idea, not a specific implementation. The exact directory structure, the schema conventions, the page formats, the tooling — all of that will depend on your domain, your preferences, and your LLM of choice. Everything mentioned above is optional and modular — pick what's useful, ignore what isn't. For example: your sources might be text-only, so you don't need image handling at all. Your wiki might be small enough that the index file is all you need, no search engine required. You might not care about slide decks and just want markdown pages. You might want a completely different set of output formats. The right way to use this is to share it with your LLM agent and work together to instantiate a version that fits your needs. The document's only job is to communicate the pattern. Your LLM can figure out the rest.
